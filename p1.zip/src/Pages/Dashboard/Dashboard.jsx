import { useEffect, useState } from "react";
import axios from "axios";
import { FaUsers, FaBox } from "react-icons/fa6";
import { IoIosWarning } from "react-icons/io";
import { TfiStatsUp } from "react-icons/tfi";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  BarChart,
  Bar,
  Legend,
} from "recharts";
import "./Dashboard.css";

const Dashboard = () => {
  const [pesanan, setPesanan] = useState([]);
  const [produk, setProduk] = useState([]);
  const [users, setUsers] = useState([]);
  const [editStokId, setEditStokId] = useState(null);
  const [stokTambah, setStokTambah] = useState("");

  const token = localStorage.getItem("token");

  useEffect(() => {
    fetchAll();
  }, []);

  const fetchAll = async () => {
    try {
      const [resOrder, resProduk, resUser] = await Promise.all([
        axios.get("http://localhost:3003/order", {
          headers: { Authorization: `Bearer ${token}` },
        }),
        axios.get("http://localhost:3003/produk", {
          headers: { Authorization: `Bearer ${token}` },
        }),
        axios.get("http://localhost:3003/user", {
          headers: { Authorization: `Bearer ${token}` },
        }),
      ]);

      setPesanan(resOrder.data.data || []);
      setProduk(resProduk.data.data || []);
      setUsers(resUser.data.data || []);
    } catch (error) {
      console.log(error.response);
    }
  };

  const month = new Date().toISOString().slice(0, 7);

  const totalPendapatanBulanIni = pesanan
    .filter((p) => p.createdAt?.startsWith(month))
    .reduce((sum, p) => sum + Number(p.totalPrice || 0), 0);

  const stokMenipis = produk.filter(
    (p) => Number(p.stok) <= Number(p.minStok || 5),
  );

  const pesananTerbaru = [...pesanan]
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 5);

  const handleSimpanStok = async (produk) => {
    try {
      const tambahan = parseInt(stokTambah);
      if (isNaN(tambahan)) return alert("Input tidak valid!");

      const newStok = produk.stok + tambahan;

      await axios.put(
        `http://localhost:3003/produk/${produk.id}`,
        { stok: Number(newStok) },
        {
          headers: { Authorization: `Bearer ${token}` },
        },
      );

      setEditStokId(null);
      setStokTambah("");
      fetchAll();
    } catch (error) {
      console.log(error.response);
    }
  };

  const grafikPendapatan = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - i));

    const tgl = date.toLocaleDateString("id-ID", {
      day: "numeric",
      month: "short",
    });

    const pesananHari = pesanan.filter((p) =>
      p.createdAt?.startsWith(date.toISOString().split("T")[0]),
    );

    return {
      tgl,
      total: pesananHari.reduce((sum, p) => sum + Number(p.totalPrice || 0), 0),
    };
  });

  const grafikJumlah = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (6 - i));

    const tgl = date.toLocaleDateString("id-ID", {
      day: "numeric",
      month: "short",
    });

    const pesananHari = pesanan.filter((p) =>
      p.createdAt?.startsWith(date.toISOString().split("T")[0]),
    );

    return {
      tgl,
      jumlah: pesananHari.length,
    };
  });

  return (
    <div className="dashboard">
      <h3>Dashboard Admin</h3>

      
      <div className="dashboard-cards">
        <div className="dashboard-card green">
          <TfiStatsUp />
          <div>
            <p>Pendapatan Bulan Ini</p>
            <h4>Rp {totalPendapatanBulanIni.toLocaleString("id-ID")}</h4>
          </div>
        </div>

        <div className="dashboard-card orange">
          <FaUsers />
          <div>
            <p>Total User</p>
            <h4>{users.length}</h4>
          </div>
        </div>

        <div className="dashboard-card red">
          <IoIosWarning />
          <div>
            <p>Stok Menipis</p>
            <h4>{stokMenipis.length}</h4>
          </div>
        </div>

        <div className="dashboard-card teal">
          <FaBox />
          <div>
            <p>Total Order</p>
            <h4>{pesanan.length}</h4>
          </div>
        </div>
      </div>

      <div className="dashboard-charts">
       
        <div className="chart-card">
          <h4>Pendapatan 7 Hari Terakhir</h4>
          <p className="chart-desc">Total transaksi per hari</p>

          <ResponsiveContainer width="100%" height={260}>
            <LineChart data={grafikPendapatan}>
              <Line
                dataKey="total"
                stroke="#22d3ee"
                strokeWidth={3}
                dot={{ r: 4 }}
                name="Pendapatan"
              />
              <XAxis dataKey="tgl" />
              <YAxis />
              <Tooltip
                formatter={(v) => `Rp ${Number(v).toLocaleString("id-ID")}`}
              />
              <Legend />
              <CartesianGrid strokeDasharray="3 3" />
            </LineChart>
          </ResponsiveContainer>
        </div>

      
        <div className="chart-card">
          <h4>Jumlah Order 7 Hari Terakhir</h4>
          <p className="chart-desc">Jumlah transaksi harian</p>

          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={grafikJumlah}>
              <Bar
                dataKey="jumlah"
                fill="#22d3ee"
                radius={[6, 6, 0, 0]}
                name="Order"
              />
              <XAxis dataKey="tgl" />
              <YAxis />
              <Tooltip formatter={(v) => `${v} Order`} />
              <Legend />
              <CartesianGrid strokeDasharray="3 3" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="dashboard-bottom">
  
        <div>
          <h4>Pesanan Terbaru</h4>

          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>User</th>
                  <th>Tanggal</th>
                  <th>Total</th>
                </tr>
              </thead>
              <tbody>
                {pesananTerbaru.map((p) => (
                  <tr key={p.id}>
                    <td>{p.user?.name || "-"}</td>
                    <td>{new Date(p.createdAt).toLocaleDateString("id-ID")}</td>
                    <td>Rp {Number(p.totalPrice).toLocaleString("id-ID")}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div>
          <h4>Stok Menipis</h4>

          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Produk</th>
                  <th>Stok</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                {stokMenipis.map((p) => (
                  <tr key={p.id}>
                    <td>{p.name}</td>
                    <td>{p.stok}</td>
                    <td>
                      {editStokId === p.id ? (
                        <>
                          <input
                            type="number"
                            value={stokTambah}
                            onChange={(e) => setStokTambah(e.target.value)}
                          />
                          <button onClick={() => handleSimpanStok(p)}>
                            Simpan
                          </button>
                          <button onClick={() => setEditStokId(null)}>
                            Batal
                          </button>
                        </>
                      ) : (
                        <button onClick={() => setEditStokId(p.id)}>
                          Tambah
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
