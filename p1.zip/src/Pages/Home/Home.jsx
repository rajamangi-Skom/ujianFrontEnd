import React, { useEffect, useState } from "react";
import axios from "axios";
import "./Home.css";
import { useNavigate } from "react-router-dom";

const Home = () => {
  const navigate = useNavigate();

  const [kategori, setKategori] = useState([]);
  const [produk, setProduk] = useState([]);
  const [activeKategori, setActiveKategori] = useState("Semua");
  const [loading, setLoading] = useState(true);

  const token = localStorage.getItem("token");

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [resKat, resProd] = await Promise.all([
        axios.get("http://localhost:3003/kategori", {
          headers: { Authorization: `Bearer ${token}` },
        }),
        axios.get("http://localhost:3003/produk", {
          headers: { Authorization: `Bearer ${token}` },
        }),
      ]);

      setKategori(resKat.data.data || []);
      setProduk(resProd.data.data || []);
    } catch (err) {
      console.log(err);
    } finally {
      setLoading(false);
    }
  };

  const filteredProduk =
    activeKategori === "Semua"
      ? produk
      : produk.filter((p) => p.kategori?.name === activeKategori);

  return (
    <div className="landing">
      <div className="hero">
        <div>
          <h1>Belanja Game Murah & Cepat 🎮</h1>
          <p>Beli game favorit dengan harga terbaik</p>
        </div>
        <button onClick={() => navigate("/dashboard/shop")}>
          Lihat Produk
        </button>
      </div>

      <div className="kategori">
        <button
          className={activeKategori === "Semua" ? "active" : ""}
          onClick={() => setActiveKategori("Semua")}
        >
          Semua
        </button>

        {kategori.map((k) => (
          <button
            key={k.id}
            className={activeKategori === k.name ? "active" : ""}
            onClick={() => setActiveKategori(k.name)}
          >
            {k.name}
          </button>
        ))}
      </div>

      {loading ? (
        <p className="loading">Loading produk...</p>
      ) : (
        <div className="produk-container">
          {filteredProduk.length === 0 ? (
            <p className="empty">Produk tidak ditemukan</p>
          ) : (
            filteredProduk.map((item) => (
              <div className="card-produk" key={item.id}>
                <img
                  src={
                    item.image
                      ? `http://localhost:3003/uploads/${item.image}`
                      : "https://picsum.photos/300/200"
                  }
                  alt={item.name}
                />
                <div className="card-body">
                  <small>{item.kategori?.name || "-"}</small>
                  <h4>{item.name}</h4>
                  <p>Stok: {item.stok}</p>
                  <h3>Rp {Number(item.price).toLocaleString("id-ID")}</h3>

                  <div className="btn-group">
                    <button className="btn-outline">+ Keranjang</button>

                    <button
                      className="btn-primary"
                      onClick={() =>
                        navigate("/dashboard/cart", {
                          state: { produk: item },
                        })
                      }
                    >
                      Beli
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
};

export default Home;
